<?php require_once("functions.php"); ?>
<?php html_head(); ?>
	<h1>HTTP 404 Non trouvé</h1>
	<p>Comme c'est dommage :/</p>
<?php html_foot(); ?>